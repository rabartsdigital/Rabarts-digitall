import React, { useEffect, useMemo, useState } from "react";
import { Copy, Globe, Languages, LogOut, Phone, QrCode, ShieldCheck, Users, Wallet } from "lucide-react";
import { Toaster, toast } from "sonner";

// ===== Config =====
const APP_NAME = "Rabarts Digital Company";
const ADMIN_MOBILE = "7310206873";
const UPI_ID = "7310***873@ybl"; // replace with real UPI ID before launch
const JOIN_PRICE = 149;

// i18n
const t = {
  en: {
    app: APP_NAME,
    tagline: "One link. Work daily. Earn smart.",
    login: "Mobile Login",
    mobile: "Mobile Number",
    sendOtp: "Send OTP",
    enterOtp: "Enter 4-digit OTP",
    verify: "Verify",
    payUnlock: "Pay to Unlock",
    upiId: "UPI ID",
    scanToPay: "Scan to Pay",
    unlocked: "Unlocked",
    dashboard: "Dashboard",
    welcome: "Welcome",
    earnings: "Earnings Range",
    perMonth: "/ month",
    copyLink: "Copy Link",
    referrals: "Referrals",
    direct: "Direct",
    yourRefCode: "Your Referral Code",
    tasks: "Daily Tasks",
    extra: "Extra Work",
    admin: "Admin",
    logout: "Logout",
    complete: "Complete",
    proofLink: "Proof Link (optional)",
    submit: "Submit",
    language: "Language",
    videoGuide: "Welcome Video Guide",
    approvePayouts: "Approve Payouts",
    payoutsNote: "Mark payouts after monthly review (demo only).",
    taskLibrary: "Task Library",
    addTask: "Add Task",
    taskTitle: "Task title",
    taskDesc: "Description (30–60 min)",
    save: "Save",
    bonusLibrary: "Bonus Library",
    addBonus: "Add Bonus",
    bonusDesc: "Bonus task (YouTube/Share/Referral milestone)",
    earningsHint: "Your daily target is visible in Tasks panel.",
    howReferralWorks: "Share your link. When someone unlocks, you get referral credit.",
    demoWarning: "Demo build — replace UPI & add backend before launch.",
    quickStart: "Quick Start",
    quickStartSteps: [
      "Login with mobile",
      `Unlock with ₹${JOIN_PRICE} (demo auto-confirms)`,
      "Open Tasks → complete and submit",
      "Share referral link to grow earnings"
    ],
  },
  hi: {
    app: APP_NAME,
    tagline: "एक लिंक. रोज़ काम. स्मार्ट कमाई.",
    login: "मोबाइल लॉगिन",
    mobile: "मोबाइल नंबर",
    sendOtp: "OTP भेजें",
    enterOtp: "4 अंकों का OTP",
    verify: "वेरिफाई",
    payUnlock: "पेमेंट कर के अनलॉक करें",
    upiId: "यूपीआई आईडी",
    scanToPay: "स्कैन कर भुगतान करें",
    unlocked: "अनलॉक हो गया",
    dashboard: "डैशबोर्ड",
    welcome: "स्वागत है",
    earnings: "कमाई रेंज",
    perMonth: "/ महीना",
    copyLink: "लिंक कॉपी करें",
    referrals: "रिफरल्स",
    direct: "डायरेक्ट",
    yourRefCode: "आपका रेफ़रल कोड",
    tasks: "डेली टास्क",
    extra: "एक्स्ट्रा वर्क",
    admin: "एडमिन",
    logout: "लॉगआउट",
    complete: "पूरा किया",
    proofLink: "प्रूफ लिंक (वैकल्पिक)",
    submit: "सबमिट",
    language: "भाषा",
    videoGuide: "वेलकम वीडियो गाइड",
    approvePayouts: "पेयाउट अप्रूवल",
    payoutsNote: "मासिक रिव्यू के बाद Paid मार्क करें (डेमो).",
    taskLibrary: "टास्क लाइब्रेरी",
    addTask: "नया टास्क जोड़ें",
    taskTitle: "टास्क शीर्षक",
    taskDesc: "विवरण (30–60 मिनट)",
    save: "सेव",
    bonusLibrary: "बोनस लाइब्रेरी",
    addBonus: "नया बोनस जोड़ें",
    bonusDesc: "बोनस टास्क (YouTube/Share/Referral milestone)",
    earningsHint: "डेली टार्गेट Tasks पैनल में दिखेगा.",
    howReferralWorks: "अपना लिंक शेयर करें — कोई अनलॉक करता है तो क्रेडिट मिलेगा.",
    demoWarning: "डेमो बिल्ड — लॉन्च से पहले UPI बदलें और बैकएंड जोड़ें.",
    quickStart: "क्विक स्टार्ट",
    quickStartSteps: [
      "मोबाइल से लॉगिन",
      `₹${JOIN_PRICE} देकर अनलॉक करें (डेमो)`,
      "Tasks खोलें → सबमिट करें",
      "कमाई बढ़ाने के लिए रेफ़रल लिंक शेयर करें"
    ],
  },
}

// utils
const uid = () => Math.random().toString(36).slice(2, 10).toUpperCase()
const ls = { get: (k,d)=>{ try{ const v = localStorage.getItem(k); return v? JSON.parse(v): d }catch{return d} }, set:(k,v)=>localStorage.setItem(k,JSON.stringify(v)), del:(k)=>localStorage.removeItem(k) }

const KEYS = { profile: 'rdc_profile', unlocked: 'rdc_unlocked', referrals: 'rdc_referrals', tasks: 'rdc_tasks', bonus: 'rdc_bonus', proofs: 'rdc_proofs', payouts: 'rdc_payouts' }

const defaultTasks = [
  { id: uid(), title: 'Watch welcome video & notes', desc: '30 min orientation', reward: 20 },
  { id: uid(), title: 'Share 2 posts on Instagram', desc: 'Use your referral link in bio', reward: 30 },
  { id: uid(), title: 'Invite 3 friends on WhatsApp', desc: 'Explain earning flow', reward: 30 },
]
const defaultBonus = [
  { id: uid(), title: 'Upload a YouTube Short (30s)', desc: 'Use #RabartsDigital & link', reward: 100 },
  { id: uid(), title: 'Hit 10 referrals milestone', desc: 'Auto badge unlock', reward: 200 },
]

export default function App(){
  const [lang, setLang] = useState('hi')
  const L = t[lang]

  const [profile, setProfile] = useState(()=>ls.get(KEYS.profile, null))
  const [otpSent, setOtpSent] = useState(false)
  const [otpInput, setOtpInput] = useState('')
  const [mobileInput, setMobileInput] = useState('')
  const [unlocked, setUnlocked] = useState(()=>ls.get(KEYS.unlocked, false))
  const [taskLib, setTaskLib] = useState(()=>ls.get(KEYS.tasks, defaultTasks))
  const [bonusLib, setBonusLib] = useState(()=>ls.get(KEYS.bonus, defaultBonus))
  const [proofs, setProofs] = useState(()=>ls.get(KEYS.proofs, {}))
  const [payouts, setPayouts] = useState(()=>ls.get(KEYS.payouts, {}))

  const isAdmin = profile?.mobile === ADMIN_MOBILE

  useEffect(()=>{ ls.set(KEYS.tasks, taskLib) },[taskLib])
  useEffect(()=>{ ls.set(KEYS.bonus, bonusLib) },[bonusLib])
  useEffect(()=>{ ls.set(KEYS.proofs, proofs) },[proofs])
  useEffect(()=>{ ls.set(KEYS.payouts, payouts) },[payouts])

# truncated due to message length - full file included in ZIP
