# Rabarts Digital Company — One-Link Web App

### Local
1. `npm install`
2. `npm run dev` → open the shown localhost URL

### Deploy (Vercel)
- Push this folder to GitHub (or drag-drop on Vercel)
- On Vercel: New Project → Import → Framework: **Vite** → Build Command: `npm run build` → Output: `dist`
- Done. You’ll get `https://<your-app>.vercel.app`

### Before Launch
- Replace `UPI_ID` in `src/App.jsx` with your real one.
- Integrate real OTP (Firebase/MSG91) and UPI webhook if you need server verification.
